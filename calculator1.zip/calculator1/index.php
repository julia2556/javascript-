<!DOCTYPE html>
<html>
<head>
	<title>Calculator</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

	<link rel="stylesheet"  href="style.css">
	<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
	
</head>
<body>
	<div class="container-fiuld">
		<h1 style="text-align: center; color: white;">This is a nice calculator</h1>
	<div class="center">

		<form name="forms">
			<input type="text" id="display" name="display" disabled="">
			<div class="buttons">
				<input type="button" id="seven" value="7">
				<input type="button" id="eight" value="8">
				<input type="button" id="nine" value="9">
				<input type="button" id="divide" value="/"><br>
				<input type="button" id="four" value="4">
				<input type="button" id="five" value="5">
				<input type="button" id="six" value="6">
				<input type="button" id="multi" value="*"><br>
				<input type="button" id="one" value="1">
				<input type="button" id="two" value="2">
				<input type="button" id="three" value="3">
				<input type="button" id="subs" value="-"><br>
				<input type="button" id="dot" value=".">
				<input type="button" id="zero" value="0">
				<input type="button" id="add" value="+">
				<input type="button" id="clear" value="c"><br>
				<input type="button" id="equal" value="=">
			</div>
		</form>

	</div>
</div>

<script src="script.js"></script>
</body>
</html>
